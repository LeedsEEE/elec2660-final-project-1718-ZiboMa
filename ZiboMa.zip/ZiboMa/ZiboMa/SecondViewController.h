//
//  SecondViewController.h
//  ZiboMa
//
//  Created by macbook on 2017/12/5.
//  Copyright © 2017年 university of leeds. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SecondViewController : UIViewController
@property (weak, nonatomic) IBOutlet UILabel *planeModel; //outlet of lable1
@property (strong, nonatomic)NSString *plane2;
@property (strong, nonatomic)NSString *number1;
@end
